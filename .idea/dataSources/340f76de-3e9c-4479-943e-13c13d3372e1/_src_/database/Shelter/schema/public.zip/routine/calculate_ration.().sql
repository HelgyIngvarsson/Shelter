create function calculate_ration() returns trigger
LANGUAGE plpgsql
AS $$
DECLARE
ration_weight real;
food_type integer;
for_pet_id integer;
pet_type integer;
BEGIN
select type_spec.type_id into pet_type 
	from type_spec where type_spec.id = NEW."type_spec";
	
if (pet_type = 1) then food_type =1; 
elseif( pet_type = 2) then food_type =2;
end if;
ration_weight = NEW."weight"*0.01+NEW."age"*0.1;
insert into ration(pet_id,food_type_id,weight) 
	values(NEW."id",food_type,ration_weight);
return NEW;
END;
$$;
