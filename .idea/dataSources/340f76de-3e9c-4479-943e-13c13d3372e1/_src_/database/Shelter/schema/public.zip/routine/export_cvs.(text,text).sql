create function export_cvs(ex_table text, path text) returns void
LANGUAGE plpgsql
AS $$
BEGIN
COPY(SELECT * from "ex_table") TO 'path'(format csv);
END;
$$;
