create function remove_ration() returns trigger
LANGUAGE plpgsql
AS $$
DECLARE
BEGIN
	delete from ration where "pet_id" = OLD."id";
return OLD;
END;
$$;
