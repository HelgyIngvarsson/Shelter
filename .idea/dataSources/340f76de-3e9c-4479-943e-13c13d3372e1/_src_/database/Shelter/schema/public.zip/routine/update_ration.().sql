create function update_ration() returns trigger
LANGUAGE plpgsql
AS $$
DECLARE
ration_weight real;
food_type integer;
for_pet_id integer;
pet_type integer;
BEGIN
ration_weight = NEW."weight"*0.01+NEW."age"*0.1;
update  ration set weight = ration_weight where pet_id = NEW."id";
return null;
END;
$$;
